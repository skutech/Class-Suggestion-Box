<?php
session_start();
include '../includes/db.php';

// Redirect to login if not logged in
if(!isset($_SESSION['admin_logged_in'])){
    header("Location: index.php");
    exit;
}

// Logout
if(isset($_GET['logout'])){
    session_destroy();
    header("Location: index.php");
    exit;
}

// Delete suggestion
if(isset($_GET['delete'])){
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM suggestions WHERE id=$id");
    header("Location: admin_dashboard.php");
    exit;
}

// Mark as reviewed
if(isset($_GET['review'])){
    $id = intval($_GET['review']);
    $conn->query("UPDATE suggestions SET reviewed=1 WHERE id=$id");
    header("Location: admin_dashboard.php");
    exit;
}

// Search filter
$searchDept = '';
$where = '';
if(isset($_GET['department']) && $_GET['department'] != ''){
    $searchDept = $_GET['department'];
    $where = "WHERE department LIKE '%".$conn->real_escape_string($searchDept)."%'";
}

// Pagination setup
$limit = 10; // rows per page
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $limit;

// Count total rows
$totalResult = $conn->query("SELECT COUNT(*) as total FROM suggestions $where");
$totalRows = $totalResult->fetch_assoc()['total'];
$totalPages = ceil($totalRows / $limit);

// Fetch suggestions
$result = $conn->query("SELECT * FROM suggestions $where ORDER BY date_submitted DESC LIMIT $limit OFFSET $offset");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Suggestions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Suggestions Admin Dashboard</h2>
        <a href="admin_dashboard.php?logout=true" class="btn btn-danger">Logout</a>
    </div>

    <!-- Search Form -->
    <form class="mb-4" method="GET" action="admin_dashboard.php">
        <div class="input-group">
            <input type="text" name="department" class="form-control" placeholder="Search by Department" value="<?php echo htmlspecialchars($searchDept); ?>">
            <button class="btn btn-primary" type="submit">Search</button>
        </div>
    </form>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Matric</th>
                <th>Email</th>
                <th>Department</th>
                <th>Suggestion</th>
                <th>Reviewed</th>
                <th>Date Submitted</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if($result->num_rows > 0){
                while($row = $result->fetch_assoc()){
                    echo "<tr>";
                    echo "<td>".$row['id']."</td>";
                    echo "<td>".htmlspecialchars($row['name'])."</td>";
                    echo "<td>".htmlspecialchars($row['Matric'])."</td>";
                    echo "<td>".htmlspecialchars($row['email'])."</td>";
                    echo "<td>".htmlspecialchars($row['department'])."</td>";
                    echo "<td>".htmlspecialchars($row['suggestion'])."</td>";
                    echo "<td>".($row['reviewed'] ? '<span class="badge bg-success">Yes</span>' : '<span class="badge bg-warning">No</span>')."</td>";
                    echo "<td>".$row['date_submitted']."</td>";
                    echo "<td>
                            ".(!$row['reviewed'] ? "<a href='admin_dashboard.php?review=".$row['id']."' class='btn btn-sm btn-success mb-1'>Mark Reviewed</a><br>" : "")."
                            <a href='admin_dashboard.php?delete=".$row['id']."' class='btn btn-sm btn-danger' onclick='return confirm(\"Delete this suggestion?\")'>Delete</a>
                          </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='9' class='text-center'>No suggestions found.</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <!-- Pagination Links -->
    <nav>
        <ul class="pagination justify-content-center">
            <?php
            for($i=1; $i<=$totalPages; $i++){
                $active = ($i==$page) ? 'active' : '';
                $link = "admin_dashboard.php?page=$i";
                if($searchDept) $link .= "&department=".urlencode($searchDept);
                echo "<li class='page-item $active'><a class='page-link' href='$link'>$i</a></li>";
            }
            ?>
        </ul>
    </nav>

</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
