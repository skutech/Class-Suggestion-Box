<?php include 'includes/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suggestion Box</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        header {
            background-color: #7b4db7; /* purple header */
            color: white;
            padding: 20px 0;
            text-align: center;
            font-size: 1.8rem;
            font-weight: bold;
            margin-bottom: 50px;
        }
        .suggestion-card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 2px 10px rgba(0,0,0,0.1);
        }
        .btn-send {
            background-color: #28a745;
            color: white;
            font-weight: bold;
        }
        .btn-send:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

<header>MAPOLY CLASS SUGGESTION</header>

<div class="container">
    <!-- Suggestion Form -->
    <div class="suggestion-card mx-auto" style="max-width: 600px;">
        <form action="submit.php" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="name" class="form-label">Your Name (optional)</label>
                <input type="text" name="name" class="form-control" id="name">
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Your Email (optional)</label>
                <input type="email" name="email" class="form-control" id="email">
            </div>
            <div class="mb-3">
                <label for="matric" class="form-label">Matric Number (optional)</label>
                <input type="text" name="matric" class="form-control" id="matric">
            </div>
            <div class="mb-3">
                <label for="department" class="form-label">Department</label>
                <input type="text" name="department" class="form-control" id="department" required>
            </div>
            <div class="mb-3">
                <label for="suggestion" class="form-label">Your Suggestion</label>
                <textarea name="suggestion" class="form-control" id="suggestion" rows="3" required></textarea>
            </div>
          
            <button type="submit" class="btn btn-send w-100">Send</button>
        </form>
    </div>
</div>
<!-- Display Latest Suggestions -->
    <h2 class="mb-3">Latest Suggestions</h2>
    <div class="row">
        <?php
        $result = $conn->query("SELECT * FROM suggestions ORDER BY date_submitted DESC");
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $cardClass = $row['reviewed'] ? 'card-reviewed' : 'card-pending';
                echo '<div class="col-md-6 mb-3">';
                echo '<div class="card '.$cardClass.'">';
                echo '<div class="card-header d-flex justify-content-between align-items-center">';
                echo htmlspecialchars($row['department']);
                echo $row['reviewed'] ? ' <span class="badge bg-success">Reviewed</span>' : ' <span class="badge bg-warning text-dark">Pending</span>';
                echo '</div>';
                echo '<div class="card-body">';
                echo '<p>'.htmlspecialchars($row['suggestion']).'</p>';
                $info = [];
                if($row['name']) $info[] = 'Name: '.htmlspecialchars($row['name']);
                if($row['Matric']) $info[] = 'Matric: '.htmlspecialchars($row['Matric']);
                if($row['email']) $info[] = 'Email: '.htmlspecialchars($row['email']);
                if($info) echo '<p class="text-muted mb-0">'.implode(' | ', $info).'</p>';
                echo '<small class="text-muted">Submitted on: '.$row['date_submitted'].'</small>';
                echo '</div></div></div>';
            }
        } else {
            echo '<p>No suggestions yet. Be the first to submit!</p>';
        }
        ?>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

