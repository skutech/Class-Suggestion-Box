<?php
include 'includes/db.php';

$name = $_POST['name'] ?? null;
$email = $_POST['email'] ?? null;
$matric = $_POST['matric'] ?? null;
$department = $_POST['department'];
$suggestion = $_POST['suggestion'];

$stmt = $conn->prepare("INSERT INTO suggestions (name, email, Matric, department, suggestion) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $name, $email, $matric, $department, $suggestion);

if($stmt->execute()){
    header("Location: index.php?success=1");
} else {
    echo "Error: ".$stmt->error;
}
?>
